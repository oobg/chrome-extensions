# Dot Braille Extension

## 최신버전 다운로드

- [Latest version (ZIP)](https://github.com/oobg/chrome-extensions/raw/refs/heads/main/dist/dot-braille-extension.zip)

## history

### 0.3.0
- 점역 결과 드래그하면 다른 결과화면에도 드래그 영역 연동
- 점역 결과 헥사 텍스트 박스와 유니코드 텍스트 박스 위치변경

### 0.2.2
- HEX 텍스트도 외곽선 및 `<mark>` 적용
- HEX 텍스트와 Unicode 텍스트 넓이 조정
- CSS 조정

### 0.2.1
- 에러 발생 시 에러 문구 리턴
- 아이콘 색상 변경

### 0.2
- CSS 적용
- 영어와 한국어만 있었던 점역 언어에 나머지 언어 추가

### 0.1
- 기본 기능 구현